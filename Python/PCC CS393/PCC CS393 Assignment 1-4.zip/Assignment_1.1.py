# 1. Write a python program to perform all arithmetic operation by accepting values for two variables.
a = eval(input("Enter a Number: "))
b = eval(input("Enter a Number: "))

print("a+b = ", a+b)
print("a-b = ", a-b)
print("a*b = ", a*b)
print("a/b = ", a/b)
print("a**b = ", a**b)
print("a//b = ", a//b)
